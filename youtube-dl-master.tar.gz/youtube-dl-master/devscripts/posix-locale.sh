
# source this file in your shell to get a POSIX locale (which will break many programs, but that's kind of the point)

export LC_ALL=POSIX
export LANG=POSIX
export LANGUAGE=POSIX
